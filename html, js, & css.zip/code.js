let dvdImage = document.getElementById("dvdImage");
let bounceSound1 = document.getElementById("bounceSound1");
let bounceSound2 = document.getElementById("bounceSound2");

let dx = 5; // horizontal speed
let dy = 5; // vertical speed
let intervalId; // store interval ID for movement

function playRandomBounceSound() {
    // randomly choose between the two audio files
    let randomSound = Math.random() < 0.5 ? bounceSound1 : bounceSound2;
    randomSound.muted = false; // makes sure sound isn't muted
    bounceSound1.volume = 1.0; // sound volume = 100%
    bounceSound2.volume = 1.0; // sound volume = 100%
    randomSound.play();
}

function startMvmt() {
    console.log("Start Movement button clicked");
    document.getElementById("startBtn").disabled = true;
    document.getElementById("stopBtn").disabled = false;
    document.getElementById("resetImgBtn").disabled = false;

    intervalId = setInterval(() => {
        console.log("Image is moving...");
        let rect = dvdImage.getBoundingClientRect(); // get the current position of the img
        let containerWidth = window.innerWidth; // get the width of the container
        let containerHeight = window.innerHeight; // get the height of the container

        // Check for collision with the edges
        if (rect.left <= 0 || rect.right >= containerWidth) {
            dx = -dx; // reverse horizontal direction
            playRandomBounceSound(); // play bounce sound
        }
        if (rect.top <= 0 || rect.bottom >= containerHeight) {
            dy = -dy; // reverse vertical direction
            playRandomBounceSound(); // play bounce sound
        }

        // update image position
        dvdImage.style.left = rect.left + dx + "px";
        dvdImage.style.top = rect.top + dy + "px";
    }, 20); // move image every 20 milliseconds (0.20 seconds)
}

function stopMvmt() {
    document.getElementById("startBtn").disabled = false;
    document.getElementById("stopBtn").disabled = true;
    document.getElementById("resetImgBtn").disabled = false;

    clearInterval(intervalId); // stop the movement of the image
}

function resetImgPosition() {
    dvdImage.style.left = "50px"; // reset to original horizontal position
    dvdImage.style.top = "210px"; // reset to original vertical position

    document.getElementById("resetImgBtn").disabled = true; // disable reset button after being clicked
}